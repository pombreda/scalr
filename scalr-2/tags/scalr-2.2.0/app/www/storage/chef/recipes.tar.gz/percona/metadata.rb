license           "Apache 2.0"
description       "Installs Percona server"
version           "0.0.1"

